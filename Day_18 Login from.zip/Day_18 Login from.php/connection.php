<?php
error_reporting(0);
$servername="localhost";
$username="root";
$password="";
$dbname="student";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{

}
else{
    echo"connection failed".mysqli_connect_error();
}
?>